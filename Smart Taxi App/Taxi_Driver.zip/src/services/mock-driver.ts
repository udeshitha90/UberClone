export let DRIVER = {
  id: 1,
  name: "Ashan Dulanja",
  plate: "WP CAA 1234",
  brand: "Honda FIT",
  ref_code: "486969",
  rating: 4,
  balance: "580",
  balance_pending: 0
}