export let REPORT = {
  today: 5,
  this_week: 15,
  this_month: 15,
  last_month: 10,
  this_year: 25,
  last_year: 0
}