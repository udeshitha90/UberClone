export let JOBS = [
  {
    id: 1,
    unique_id: "ADR-0000016-1-048",
    date: "2015-02-22 16:04:00",
    from: {
      title: "Galle",
      address: "No 20 Nguyen Trai, Ha Noi, Viet Nam",
      distance: 0.6
    },
    to: {
      title: "Colombo",
      address: "No 320 Minh Khai st, Ha Noi, Viet Nam"
    },
    customer: {
      name: "Dao Duy Thanh",
      phone: "+84941727190"
    },
    payment_method: "cash"
  },
  {
    id: 2,
    unique_id: "ADR-0000016-1-048",
    date: "2015-02-22 16:04:00",
    from: {
      title: "Royal City",
      address: "No 20 Nguyen Trai, Ha Noi, Viet Nam",
      distance: 0.6
    },
    to: {
      title: "Times City",
      address: "No 320 Minh Khai st, Ha Noi, Viet Nam"
    },
    customer: {
      name: "Dao Duy Thanh",
      phone: "+84941727190"
    },
    payment_method: "cash"
  },
  {
    id: 3,
    unique_id: "ADR-0000016-1-048",
    date: "2015-02-22 16:04:00",
    from: {
      title: "Royal City",
      address: "No 20 Nguyen Trai, Ha Noi, Viet Nam",
      distance: 0.6
    },
    to: {
      title: "Times City",
      address: "No 320 Minh Khai st, Ha Noi, Viet Nam"
    },
    customer: {
      name: "Dao Duy Thanh",
      phone: "+84941727190"
    },
    payment_method: "cash"
  },
  {
    id: 4,
    unique_id: "ADR-0000016-1-048",
    date: "2015-02-22 16:04:00",
    from: {
      title: "Royal City",
      address: "No 20 Nguyen Trai, Ha Noi, Viet Nam",
      distance: 0.6
    },
    to: {
      title: "Times City",
      address: "No 320 Minh Khai st, Ha Noi, Viet Nam"
    },
    customer: {
      name: "Dao Duy Thanh",
      phone: "+84941727190"
    },
    payment_method: "cash"
  },
  {
    id: 5,
    unique_id: "ADR-0000016-1-048",
    date: "2015-02-22 16:04:00",
    from: {
      title: "Royal City",
      address: "No 20 Nguyen Trai, Ha Noi, Viet Nam",
      distance: 0.6
    },
    to: {
      title: "Times City",
      address: "No 320 Minh Khai st, Ha Noi, Viet Nam"
    },
    customer: {
      name: "Dao Duy Thanh",
      phone: "+84941727190"
    },
    payment_method: "cash"
  }
]