export let TRANSACTIONS = [
  {
    id: 1,
    unique_id: "WD-0000016-1-048",
    date: "2017-02-22 16:04:00",
    amount: 1000,
    action: "withdraw"
  },
  {
    id: 2,
    unique_id: "WD-0000016-1-048",
    date: "2017-02-22 16:04:00",
    amount: 1000,
    action: "withdraw"
  },
  {
    id: 3,
    unique_id: "WD-0000016-1-048",
    date: "2017-02-22 16:04:00",
    amount: 1000,
    action: "withdraw"
  },
  {
    id: 4,
    unique_id: "WD-0000016-1-048",
    date: "2017-02-22 16:04:00",
    amount: 1000,
    action: "withdraw"
  }
]