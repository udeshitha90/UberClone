import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import {RegisterPage} from '../register/register';
import {HomePage} from '../home/home'
import { Http } from '@angular/http';
import { AlertController } from 'ionic-angular';
import 'rxjs/add/operator/map'

@Component({
  selector: 'page-login',
  templateUrl: 'login.html'
})
export class LoginPage {
  user: {
    name: string;
    password: string;
  };
  ApiUrl = 'http://api.techwirelanka.com/VOWServiceTest/VOW_WebService.svc/Login/';
  public status;
  public name;

  constructor(public nav: NavController,private http:Http,private alertCtrl: AlertController) {
    this.user={name:'',password:''};
  }
  signup() {
    this.nav.setRoot(RegisterPage);
  }

  login() {
    let headers = new Headers({ 'Content-Type': 'application/json; charset=utf-8' });
    let body = new FormData();
    body.append('Username', 'abc');
    body.append('Password', '123');
    body.append('IMEI', '0');
    console.log(body);
    console.log(headers);
    this.http.post(this.ApiUrl+this.user.name+'/'+this.user.password+'/0',body,headers)
    .map(res => res.json())
        .subscribe(
            data => {
              console.log(data);
              console.log("post ok");
               status = data.LoginResult.Success
               console.log("Data: ", status);
                if (data.LoginResult.Success == 1){
                  this.nav.setRoot(HomePage);
                  //this.nav.push(HomePage)
                  this.presentAlert('Successfully login !')
                }
                else
                 this.presentAlert('Please try agin !');
            },
            err => {
              console.log("ERROR!: ", err)
             
            }
        );
       
  }
  presentAlert(message) {
  let alert = this.alertCtrl.create({
    title: 'Login',
    subTitle: message,
    buttons: ['Dismiss']
  });
  alert.present();
}
}
